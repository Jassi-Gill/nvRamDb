package com.yahoo.ycsb.db;

import site.ycsb.ByteIterator;
import site.ycsb.DB;
import site.ycsb.DBException;
import site.ycsb.Status;
import site.ycsb.StringByteIterator;

import com.yahoo.ycsb.*;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;
// Removed: import java.util.concurrent.TimeUnit; // Unused import

/**
 * YCSB binding for the custom C socket server.
 *
 * Properties:
 * - yourdb.host=... (default: 127.0.0.1)
 * - yourdb.port=... (default: 8080)
 * - yourdb.table=... (default: usertable) - The table YCSB will use.
 */
public class YourDBClient extends DB {
  private static final String HOST_PROPERTY = "yourdb.host";
  private static final String PORT_PROPERTY = "yourdb.port";
  private static final String TABLE_PROPERTY = "yourdb.table";
  private static final String DEFAULT_HOST = "127.0.0.1";
  private static final int DEFAULT_PORT = 8080;
  private static final String DEFAULT_TABLE = "usertable"; // YCSB default table name

  private Socket socket;
  private PrintWriter out;
  private BufferedReader in;
  private String tableName;

  // NOTE: Removed commented out lock code for brevity and because it wasn't fully implemented.

  @Override
  public void init() throws DBException {
    Properties props = getProperties();
    String host = props.getProperty(HOST_PROPERTY, DEFAULT_HOST);
    int port = Integer.parseInt(props.getProperty(PORT_PROPERTY, String.valueOf(DEFAULT_PORT)));
    tableName = props.getProperty(TABLE_PROPERTY, DEFAULT_TABLE);

    try {
      System.err.println("Connecting to " + host + ":" + port + " for table " + tableName);
      socket = new Socket(host, port);
      out = new PrintWriter(socket.getOutputStream(), true); // Auto-flush
      in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

      // Ensure table exists and is selected for this connection
      sendCommand("CREATE TABLE " + tableName);
      // Ignore response for create, maybe it already exists
      readResponse(); // Consume the response

      sendCommand("USE TABLE " + tableName);
      String response = readResponse();
      if (response == null || !response.startsWith("Table opened")) {
        System.err.println("Server response to USE TABLE: " + response);
        // Throw exception even if create succeeded but use failed
        throw new DBException("Failed to USE TABLE " + tableName + ". Response: " + response);
      }
      System.err.println("Connection successful and table '" + tableName + "' selected.");

    } catch (UnknownHostException e) {
      throw new DBException("Unknown host: " + host, e);
    } catch (IOException e) {
      throw new DBException("Error connecting or setting up connection to " + host + ":" + port, e);
    } catch (Exception e) {
      throw new DBException("Unexpected error during init", e);
    }
  }

  @Override
  public void cleanup() throws DBException {
    try {
      // Added braces for consistency
      if (out != null) {
        out.close();
      }
      if (in != null) {
        in.close();
      }
      if (socket != null && !socket.isClosed()) {
        socket.close();
      }
      System.err.println("Connection closed.");
    } catch (IOException e) {
      throw new DBException("Error closing connection", e);
    }
  }

  // --- Helper Methods ---

  private int keyToInt(String key) {
    // WARNING: Using hashCode() is a simple but potentially problematic way
    // to convert String keys to int keys required by the server.
    // Collisions WILL occur for different string keys mapping to the same int.
    // A better approach is to modify the server to accept string keys.
    // Or, if YCSB keys are guaranteed numeric strings, use Integer.parseInt().
    try {
      // Attempt to parse if key looks numeric, otherwise use hashCode
      return Integer.parseInt(key.replaceAll("[^0-9]", "")); // Extract digits
    } catch (NumberFormatException e) {
      // Fallback to hashCode if not purely numeric
      int hash = key.hashCode();
      // Broke long line:
      System.err.println("Warning: Converting key '" + key
          + "' to int using hashCode(): " + hash);
      return hash;
    }
  }

  private String serializeValues(Map<String, ByteIterator> values) {
    // Simple serialization: concatenate field=value pairs.
    // The server expects a single string blob.
    // A more robust format like JSON could be used if the server supported it.
    StringBuilder sb = new StringBuilder();
    for (Map.Entry<String, ByteIterator> entry : values.entrySet()) {
      if (sb.length() > 0) {
        sb.append("&"); // Separator
      }
      sb.append(entry.getKey()).append("=").append(entry.getValue().toString());
    }
    // Escape single quotes within the data if necessary for the server's parsing
    return sb.toString().replace("'", "''");
  }

  private Map<String, ByteIterator> deserializeValues(String data) {
    // Simple deserialization based on the format used in serializeValues.
    // Since the server just returns the blob, we put it all in one field.
    Map<String, ByteIterator> result = new HashMap<>();
    // YCSB typically expects specific fields (field0, field1, etc.)
    // For simplicity here, just put the whole blob back.
    result.put("field0", new StringByteIterator(data));
    return result;
  }


  private synchronized String sendCommand(String command) throws IOException {
    if (out == null || in == null || socket == null || socket.isClosed()) {
      throw new IOException("Connection is not active.");
    }
    // System.err.println("Sending: " + command); // Debug
    out.println(command); // println adds the newline
    return readResponse();
  }

  private String readResponse() throws IOException {
    String response = in.readLine(); // Reads until newline
    // System.err.println("Received: " + response); // Debug
    if (response == null) {
      // Server likely closed connection
      throw new IOException("Server closed connection unexpectedly.");
    }
    return response;
  }

  // --- DB Operations ---

  @Override
  public Status read(String table, String key, Set<String> fields, Map<String, ByteIterator> result) {
    // 'table' parameter is ignored, using table from init()
    int intKey = keyToInt(key);
    try {
      String response = sendCommand("GET ROW " + intKey);

      if (response.startsWith("Row " + intKey + ": ")) {
        String data = response.substring(("Row " + intKey + ": ").length());
        // Deserialize based on how data was stored, or just put the raw string
        result.putAll(deserializeValues(data)); // Populate the result map
        return Status.OK;
      } else if (response.startsWith("Row not found")) {
        return Status.NOT_FOUND;
      } else if (response.startsWith("No active transaction")) {
        // Try starting one? Or indicate error.
        System.err.println("Error during GET: Server reported no active transaction.");
        return Status.ERROR; // Or maybe retry logic?
      } else {
        System.err.println("Error during GET: Unexpected response: " + response);
        return Status.ERROR;
      }

    } catch (IOException e) {
      System.err.println("Network error during read for key " + key + ": " + e.getMessage());
      return Status.ERROR;
    } catch (Exception e) {
      System.err.println("Unexpected error during read for key " + key + ": " + e.getMessage());
      e.printStackTrace();
      return Status.ERROR;
    }
  }

  @Override
  public Status insert(String table, String key, Map<String, ByteIterator> values) {
    // 'table' parameter is ignored, using table from init()
    int intKey = keyToInt(key);
    String data = serializeValues(values);
    Status status = Status.ERROR; // Default status

    try {
      sendCommand("BEGIN TRANSACTION"); // Start transaction for insert
      String insertResponse = sendCommand(String.format("INSERT ROW %d '%s'", intKey, data));

      if (insertResponse.startsWith("Row inserted")) {
        String commitResponse = sendCommand("COMMIT");
        if (commitResponse.startsWith("Transaction committed")) {
          status = Status.OK;
        } else {
          // Broke long line
          System.err.println("Error: COMMIT failed after successful insert for key "
              + key + ". Response: " + commitResponse);
          status = Status.ERROR; // Commit failed, operation effectively failed
        }
      } else if (insertResponse.startsWith("Row already exists")) {
        // YCSB expects insert to succeed unless error. Duplicate is an error condition here.
        System.err.println("Insert failed for key " + key + ": Row already exists.");
        sendCommand("ABORT"); // Abort the transaction
        status = Status.FORBIDDEN; // Or ERROR, indicates violation
      } else if (insertResponse.startsWith("No active transaction")) {
        System.err.println("Error during INSERT: Server reported no active transaction after BEGIN.");
        status = Status.ERROR;
      } else {
        System.err.println("Error during INSERT for key " + key + ". Response: " + insertResponse);
        sendCommand("ABORT"); // Abort on failure
        status = Status.ERROR;
      }
    } catch (IOException e) {
      System.err.println("Network error during insert for key " + key + ": " + e.getMessage());
      status = Status.ERROR;
      // Attempt to clean up transaction state on error
      try {
        sendCommand("ABORT");
      } catch (Exception abortEx) { /* Ignore */ }
    } catch (Exception e) {
      System.err.println("Unexpected error during insert for key " + key + ": " + e.getMessage());
      status = Status.ERROR;
      try {
        sendCommand("ABORT");
      } catch (Exception abortEx) { /* Ignore */ }
    }
    return status;
  }

  @Override
  public Status delete(String table, String key) {
    // 'table' parameter is ignored, using table from init()
    int intKey = keyToInt(key);
    Status status = Status.ERROR;

    try {
      sendCommand("BEGIN TRANSACTION");
      String deleteResponse = sendCommand("DELETE ROW " + intKey);

      if (deleteResponse.startsWith("Row deleted")) {
        String commitResponse = sendCommand("COMMIT");
        if (commitResponse.startsWith("Transaction committed")) {
          status = Status.OK;
        } else {
          // Broke long line
          System.err.println("Error: COMMIT failed after successful delete for key "
              + key + ". Response: " + commitResponse);
          status = Status.ERROR;
        }
      } else if (deleteResponse.startsWith("Failed to delete row")) {
        // This could mean "not found" or another error. YCSB distinguishes.
        // Let's assume "not found" for now, might need server enhancement.
        // Broke long line
        System.err.println("Delete failed for key " + key
            + " (assuming not found). Response: " + deleteResponse);
        sendCommand("ABORT");
        status = Status.NOT_FOUND; // Treat failure as likely "not found"
      } else if (deleteResponse.startsWith("No active transaction")) {
        System.err.println("Error during DELETE: Server reported no active transaction after BEGIN.");
        status = Status.ERROR;
      } else {
        System.err.println("Error during DELETE for key " + key + ". Response: " + deleteResponse);
        sendCommand("ABORT");
        status = Status.ERROR;
      }

    } catch (IOException e) {
      System.err.println("Network error during delete for key " + key + ": " + e.getMessage());
      status = Status.ERROR;
      try {
        sendCommand("ABORT");
      } catch (Exception abortEx) { /* Ignore */ }
    } catch (Exception e) {
      System.err.println("Unexpected error during delete for key " + key + ": " + e.getMessage());
      status = Status.ERROR;
      try {
        sendCommand("ABORT");
      } catch (Exception abortEx) { /* Ignore */ }
    }
    return status;
  }

  @Override
  public Status update(String table, String key, Map<String, ByteIterator> values) {
    // Your server uses INSERT for updates (put semantics).
    // We can call insert, but treat "Row already exists" differently.
    // Let's re-implement slightly for clarity.
    int intKey = keyToInt(key);
    String data = serializeValues(values);
    Status status = Status.ERROR; // Default status

    try {
      sendCommand("BEGIN TRANSACTION"); // Start transaction for update
      // Using INSERT ROW as the server doesn't have a dedicated UPDATE
      String updateResponse = sendCommand(String.format("INSERT ROW %d '%s'", intKey, data));

      if (updateResponse.startsWith("Row inserted") || updateResponse.startsWith("Row already exists")) {
        // Treat both new insert and overwrite (implied by "already exists") as success for UPDATE.
        String commitResponse = sendCommand("COMMIT");
        if (commitResponse.startsWith("Transaction committed")) {
          status = Status.OK;
        } else {
          // Broke long line
          System.err.println("Error: COMMIT failed after successful update/insert for key "
              + key + ". Response: " + commitResponse);
          status = Status.ERROR; // Commit failed, operation effectively failed
        }
      } else if (updateResponse.startsWith("No active transaction")) {
        System.err.println("Error during UPDATE: Server reported no active transaction after BEGIN.");
        status = Status.ERROR;
      } else {
        System.err.println("Error during UPDATE for key " + key + ". Response: " + updateResponse);
        sendCommand("ABORT"); // Abort on failure
        status = Status.ERROR;
      }

    } catch (IOException e) {
      System.err.println("Network error during update for key " + key + ": " + e.getMessage());
      status = Status.ERROR;
      try {
        sendCommand("ABORT");
      } catch (Exception abortEx) { /* Ignore */ }
    } catch (Exception e) {
      System.err.println("Unexpected error during update for key " + key + ": " + e.getMessage());
      status = Status.ERROR;
      try {
        sendCommand("ABORT");
      } catch (Exception abortEx) { /* Ignore */ }
    }
    return status;
  }


  @Override
  public Status scan(String table, String startkey, int recordcount, Set<String> fields,
                     Vector<HashMap<String, ByteIterator>> result) {
    // Your server protocol does not support range scans.
    System.err.println("SCAN operation is not supported by this binding.");
    return Status.NOT_IMPLEMENTED;
  }
}
