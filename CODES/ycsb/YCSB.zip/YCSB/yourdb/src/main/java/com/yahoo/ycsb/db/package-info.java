/**
 * YCSB DB binding for YourDB.
 */
package com.yahoo.ycsb.db;
